require 'sinatra'
require 'stripe'

# This is your test secret API key.
Stripe.api_key = 'sk_test_51N8QO3JE2alzfsnTP44zF0HwoB7frH0tOnLta5XnBZrf2bn4tpm2g4qnBTsp62bOd4zFAT4isFcZm5EP7cqweAGc004jE41XY1'

Stripe.api_version = '2023-10-16'

set :static, true
set :port, 4242
set :public_folder, 'dist'

post '/account/:account' do
  content_type 'application/json'

  begin
    connected_account_id = params[:account]
    account = Stripe::Account.update(
      connected_account_id,
      {
        business_type: 'individual',
      }
    )

    {
      account: account[:id]
    }.to_json
  rescue => error
    puts "An error occurred when calling the Stripe API to update an account: #{error.message}";
    return [500, { error: error.message }.to_json]
  end
end

post '/account' do
  content_type 'application/json'

  begin
    account = Stripe::Account.create({
      controller: {
        stripe_dashboard: {
          type: "none",
        },
        fees: {
          payer: "application"
        },
        losses: {
          payments: "application"
        },
        requirement_collection: "application",
      },
      capabilities: {
        card_payments: {requested: true},
        transfers: {requested: true}
      },
      country: "US",
    })

    {
      account: account[:id]
    }.to_json
  rescue => error
    puts "An error occurred when calling the Stripe API to create an account: #{error.message}";
    return [500, { error: error.message }.to_json]
  end
end

get '/*path' do
  send_file File.join(settings.public_folder, 'index.html')
end